import os
import io
import numpy as np
from PIL import Image

from flask import Flask, render_template, request
import tensorflow as tf

# --------------------------
# CONFIG
# --------------------------
MODEL_PATH = "leaf_model_limited.h5"  
IMG_SIZE = (224, 224)

# Class names – must match the order used during training
class_names = [
    'Apple___Apple_scab',
    'Apple___Black_rot',
    'Apple___Cedar_apple_rust',
    'Apple___healthy',
    'Blueberry___healthy',
    'Cherry_(including_sour)___Powdery_mildew',
    'Cherry_(including_sour)___healthy',
    'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot',
    'Corn_(maize)___Common_rust_',
    'Corn_(maize)___Northern_Leaf_Blight',
    'Corn_(maize)___healthy',
    'Grape___Black_rot',
    'Grape___Esca_(Black_Measles)',
    'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)',
    'Grape___healthy',
    'Orange___Haunglongbing_(Citrus_greening)',
    'Peach___Bacterial_spot',
    'Peach___healthy',
    'Pepper,_bell___Bacterial_spot',
    'Pepper,_bell___healthy',
    'Potato___Early_blight',
    'Potato___Late_blight',
    'Potato___healthy',
    'Raspberry___healthy',
    'Soybean___healthy',
    'Squash___Powdery_mildew',
    'Strawberry___Leaf_scorch',
    'Strawberry___healthy',
    'Tomato___Bacterial_spot',
    'Tomato___Early_blight',
    'Tomato___Late_blight',
    'Tomato___Leaf_Mold',
    'Tomato___Septoria_leaf_spot',
    'Tomato___Spider_mites Two-spotted_spider_mite',
    'Tomato___Target_Spot',
    'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato___Tomato_mosaic_virus',
    'Tomato___healthy'
]

# --------------------------
# FLASK APP
# --------------------------
# template_folder='.' so index.html can live in same folder
app = Flask(__name__, template_folder='.')

# Load model once when app starts
print("Loading model...")
model = tf.keras.models.load_model(MODEL_PATH)
print("Model loaded.")


def preprocess_image(file_storage):
    """Read uploaded image and convert to model-ready tensor."""
    image_bytes = file_storage.read()
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    img = img.resize(IMG_SIZE)
    arr = np.array(img) / 255.0
    arr = np.expand_dims(arr, axis=0)  # shape (1, 224, 224, 3)
    return arr


def predict_leaf(file_storage):
    """Run model prediction and compute affected percentage."""
    img_tensor = preprocess_image(file_storage)

    probs = model.predict(img_tensor, verbose=0)[0]  # shape (38,)
    idx = int(np.argmax(probs))

    predicted_class = class_names[idx]
    confidence = float(probs[idx])

    # all "healthy" indices
    healthy_indices = [i for i, name in enumerate(class_names)
                       if "healthy" in name.lower()]
    healthy_prob = float(np.sum(probs[healthy_indices]))

    # Affected% logic v2:
    if "healthy" in predicted_class.lower():
        affected_percent = (1.0 - confidence) * 100.0
    else:
        affected_percent = confidence * 100.0

    return {
        "predicted_class": predicted_class,
        "confidence": round(confidence * 100.0, 2),          # as %
        "healthy_prob": round(healthy_prob * 100.0, 2),      # as %
        "affected_percent": round(affected_percent, 2)       # already %
    }


# --------------------------
# ROUTES
# --------------------------
@app.route("/", methods=["GET"])
def index():
    # First page load – no prediction
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    if "leaf_image" not in request.files:
        return render_template("index.html",
                               error="No file part in the request.")

    file = request.files["leaf_image"]

    if file.filename == "":
        return render_template("index.html",
                               error="No file selected.")

    try:
        result = predict_leaf(file)
        return render_template(
            "index.html",
            predicted_class=result["predicted_class"],
            confidence=result["confidence"],
            healthy_prob=result["healthy_prob"],
            affected_percent=result["affected_percent"]
        )
    except Exception as e:
        print("Prediction error:", e)
        return render_template("index.html",
                               error=f"Error while processing image: {e}")


if __name__ == "__main__":
    # For local testing
    app.run(host="0.0.0.0", port=5000, debug=True)
